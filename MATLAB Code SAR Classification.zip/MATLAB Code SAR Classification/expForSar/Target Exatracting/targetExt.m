clear all
clc
fullname = get_full_filename(filename);

pic=imread([pwd,'\HB03788.jpg']);

pic_bw=im2bw(pic);

subplot(3,2,1);
imshow(pic);

subplot(3,2,2);
imhist(pic);

subplot(3,2,3);
pic_heq=histeq(pic);
imhist(pic_heq);

subplot(3,2,4);
histeq(pic);

h=fspecial('average',9);
pic_filt=imfilter(pic_heq,h);

subplot(3,2,5);
imshow(pic_filt);

subplot(3,2,6);
im2bw(pic_filt,0.8);

fimg=im2bw(pic_filt,0.8);


imshow(fimg);
%r=regionprops(fimg,'all');