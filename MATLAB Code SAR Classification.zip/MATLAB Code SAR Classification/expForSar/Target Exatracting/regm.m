A=im2bw(imread('t722.png'));
B=im2bw(imread('bmp.png'));

%A=[1 1 1;1 1 1;1 1 1];
%B=[1 1 1;0 0 0;1 1 1];

%overlapImage = A & B;
% To count number of pixels
%numOverlapPixels = nnz(overlapImage);

% Find out where either mask is true.
unionMask = A | B;
% Find the differences. Not used - just for fun/visualization.
%xorMask = xor(flippedMask, mask);
% Find the common/overlap area.
andMask = A & B;
% Compute the Dice Coefficient
dice = nnz(andMask) / nnz(unionMask);

 c=corr2(A,B);