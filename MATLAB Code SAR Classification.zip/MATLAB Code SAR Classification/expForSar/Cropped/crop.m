images = dir('img\*.jpg') ;  % GEt all images of the folder 
N = length(images) ;     % number o fimages 
%I = imread(['img\',images(1).name]) ;  % crop one to get rect 
%[x, rect] = imcrop(I) ;
rect=[1,1,127,127]
for i = 1:N
    I = imread(['img\',images(i).name]) ;   % REad image 
    I = imcrop(I,rect) ;           % crop image 
    [filepath,name,ext] = fileparts(images(i).name) ;
    imwrite(I,strcat(name,ext)) ;   % Save image 
end
%subplot(1,2,1);
%imshow(I);
%subplot(1,2,2);
%imshow(['img\HB19377.jpg']);