a = imread('HB03787.tif'); 
%a = rgb2gray(imread('HB03787.tif')); 
b = imbinarize(a);
%img=imread('HB03819.tif');
 se = strel('disk', 8, 8); % Structuring element for dilation
 c = imdilate(b, se); % Dilating the image
 d = imfill(c,'holes'); % Filling the holes

% pic_heq=histeq(img);
% 
% h=fspecial('average',3);
% pic_filt=imfilter(pic_heq,h);
% 
% 
% bw=im2bw(pic_filt,0.8);
% 
% bw2=bwareaopen(bw,30);
% 
% se = strel('diamond',7);
% target=imclose(bw2,se);



montage({a,d});

