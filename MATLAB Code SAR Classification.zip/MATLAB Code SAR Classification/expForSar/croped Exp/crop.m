 x_cent = 120;
    y_cent = 120;
    size_of_cropped_img = 200;
    centroide = [x_cent y_cent];
    I = imread('tank.jpg');
    imshow(I);
    %I2 = imcrop(I,rect) crops the image I. rect is a four-element position vector of the
    %form [xmin ymin width height] that specifies the size and position of the crop rectangle. 
    %imcrop returns the cropped image, I2.
    xmin = x_cent-size_of_cropped_img/2;
    ymin = y_cent-size_of_cropped_img/2;
    I2 = imcrop(I,[xmin ymin size_of_cropped_img size_of_cropped_img]);
    figure();
    imshow(I2)