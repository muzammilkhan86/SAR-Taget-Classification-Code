
clear all
clc
sourcePath=([pwd,'\SAR\Img\TestSet\EOC30Less\2S1\']);
Files = dir([sourcePath,'*.jpg']);
for i = 1:length(Files)
   img=imread([sourcePath,Files(i).name]);
   a=bTarget(img);
   s = regionprops(a);
numBlob = numel(s);

if numBlob>1
else
    disp(Files(i).name);  
  r(i,:)=regionprops(a,'all');
end
   sf(i,:)=[r(i).Area,r(i).MajorAxisLength,r(i).MinorAxisLength,r(i).Eccentricity,r(i).Orientation,...
       r(i).ConvexArea,r(i).Circularity,r(i).FilledArea,r(i).EulerNumber,r(i).EquivDiameter,...
       r(i).Solidity,r(i).Extent,r(i).Perimeter,r(i).PerimeterOld,r(i).MaxFeretDiameter,...
      r(i).MaxFeretAngle,r(i).MinFeretDiameter,r(i).MinFeretAngle];
  arr(i,:)={Files(i).name};
% imshow(a);
 %pause;
end
% %----------------------------------------------------------
sourcePath=([pwd,'\SAR\Img\TestSet\EOC30Less\BRDM_2\']);
Files = dir([sourcePath,'*.jpg']);
for i = 1:length(Files)
   img=imread([sourcePath,Files(i).name]);
   a=bTarget(img);
   s = regionprops(a);
numBlob = numel(s);

if numBlob>1
  disp(Files(i).name);  
else
    disp(Files(i).name);  
  r(i,:)=regionprops(a,'all');
end
   brdmf(i,:)=[r(i).Area,r(i).MajorAxisLength,r(i).MinorAxisLength,r(i).Eccentricity,r(i).Orientation,...
       r(i).ConvexArea,r(i).Circularity,r(i).FilledArea,r(i).EulerNumber,r(i).EquivDiameter,...
       r(i).Solidity,r(i).Extent,r(i).Perimeter,r(i).PerimeterOld,r(i).MaxFeretDiameter,...
      r(i).MaxFeretAngle,r(i).MinFeretDiameter,r(i).MinFeretAngle];
  arr(i,:)={Files(i).name};
 %imshow(a);
 %pause;
end
%-----------------------------------------------------------------
sourcePath=([pwd,'\SAR\Img\TestSet\EOC30Less\ZSU_23_4\']);
Files = dir([sourcePath,'*.jpg']);
for i = 1:length(Files)
   img=imread([sourcePath,Files(i).name]);
   a=bTarget(img);
   s = regionprops(a);
numBlob = numel(s);

if numBlob>1
  disp(Files(i).name);  
else
  r(i,:)=regionprops(a,'all');
end
   zsuf(i,:)=[r(i).Area,r(i).MajorAxisLength,r(i).MinorAxisLength,r(i).Eccentricity,r(i).Orientation,...
       r(i).ConvexArea,r(i).Circularity,r(i).FilledArea,r(i).EulerNumber,r(i).EquivDiameter,...
       r(i).Solidity,r(i).Extent,r(i).Perimeter,r(i).PerimeterOld,r(i).MaxFeretDiameter,...
      r(i).MaxFeretAngle,r(i).MinFeretDiameter,r(i).MinFeretAngle];
  arr(i,:)={Files(i).name};
 %imshow(a);
 %pause;
end

 te30lFeatures=[sf;brdmf;zsuf];