%I1 = imread('c1.png');
% some calculations which result in binary image
%a=imread([pwd,'\expForSar\Angle\img\1.png']);
a=imread('asc.tif');
b=im2bw(a);
%b=imclose(b);
%I2 = imread('c1.png'); % Assuming there is a single object in the image
[L, num]= bwlabel(b);

CC = bwconncomp(L)

stats = regionprops(L, 'Orientation') ;
stats.Orientation
imshow(b);

sta= regionprops(L,'all') ;
%az=azimuth(sta.MaxFeretCoordinates)
info = regionprops(L,'Boundingbox') ;
imshow(L)
hold on
for k = 1 : length(info)
     BB = info(k).BoundingBox;
     rectangle('Position', [BB(1),BB(2),BB(3),BB(4)],'EdgeColor','r','LineWidth',2) ;
end

