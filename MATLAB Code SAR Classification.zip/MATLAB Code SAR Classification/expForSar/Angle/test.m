clc;    % Clear the command window.
close all;  % Close all figures (except those of imtool.)
clear;  % Erase all existing variables. Or clearvars if you want.
workspace;  % Make sure the workspace panel is showing.
format long g;
format compact;
fontSize = 20;
%===============================================================================
% Have user browse for a file, from a specified "starting folder."
% For convenience in browsing, set a starting folder from which to browse.
startingFolder = pwd
if ~exist(startingFolder, 'dir')
  % If that folder doesn't exist, just start in the current folder.
  startingFolder = pwd;
end
% Get the name of the file that the user wants to use.
defaultFileName = fullfile(startingFolder, '*.png');
[baseFileName, folder] = uigetfile(defaultFileName, 'Select a file');
if baseFileName == 0
  % User clicked the Cancel button.
  return;
end
% Get the full filename, with path prepended.
fullFileName = fullfile(folder, baseFileName);
% Check if file exists.
if ~exist(fullFileName, 'file')
  % The file doesn't exist -- didn't find it there in that folder.
  % Check the entire search path (other folders) for the file by stripping off the folder.
  fullFileNameOnSearchPath = baseFileName; % No path this time.
  if ~exist(fullFileNameOnSearchPath, 'file')
    % Still didn't find it.  Alert user.
    errorMessage = sprintf('Error: %s does not exist in the search path folders.', fullFileName);
    uiwait(warndlg(errorMessage));
    return;
  end
end
grayImage = imread(fullFileName);
% Get the dimensions of the image.
% numberOfColorChannels should be = 1 for a gray scale image, and 3 for an RGB color image.
[rows, columns, numberOfColorChannels] = size(grayImage);
if numberOfColorChannels > 1
  % It's not really gray scale like we expected - it's color.
  % Use weighted sum of ALL channels to create a gray scale image.
%   grayImage = rgb2gray(grayImage);
  % ALTERNATE METHOD: Convert it to gray scale by taking only the green channel,
  % which in a typical snapshot will be the least noisy channel.
  grayImage = grayImage(:, :, 1); % Take red channel.
end
% Display the image.
subplot(1, 2, 1);
imshow(grayImage, []);
title('Original Grayscale Image', 'FontSize', fontSize, 'Interpreter', 'None');
hp = impixelinfo;
axis on;
%------------------------------------------------------------------------------
% Set up figure properties:
% Enlarge figure to full screen.
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.96]);
drawnow;
% % Display the image.
% subplot(1, 2, 2);
% histogram(grayImage);
% title('Histogram of Image', 'FontSize', fontSize, 'Interpreter', 'None');
% grid on;
% Threshold the image.
% threshold(filteredImage)
binaryImage = grayImage > 120;  % Hgh enough to get rid of bad JPEG artifacts.  Never use JPEG for image analysis!
% Get rid of white surround.
binaryImage = imclearborder(binaryImage);
% Merge/connect close blobs.
se = strel('disk', 3, 0);
binaryImage = imclose(binaryImage, se);
% Display the image.
subplot(1, 2, 2);
imshow(binaryImage, []);
title('Binary Image', 'FontSize', fontSize, 'Interpreter', 'None');
drawnow;
% Get orientation:
props = regionprops(binaryImage, 'Orientation', 'Centroid');
allOrientations = [props.Orientation]
hold on;
% Plot crosses over centroid.
for k = 1 : length(props)
  x = props(k).Centroid(1);
  y = props(k).Centroid(2);
  plot(x, y, 'r+', 'MarkerSize', 30, 'LineWidth', 2);
  caption = sprintf('     Angle = %.3f', props(k).Orientation);
  text(x, y, caption, 'Color', 'r', 'FontSize', 18, 'FontWeight', 'bold');
end