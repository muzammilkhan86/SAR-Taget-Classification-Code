MSTAR2JPG([pwd,'\expForSar\Converting2jpg\SAR\'],[pwd,'\expForSar\Converting2jpg\TIF\']);
