function MSTAR2JPG(sourcePath, targetPath)

if ~exist(targetPath,'dir')
    mkdir(targetPath);
end
Files = dir(sourcePath);
for i = 1:length(Files)
    if Files(i).isdir == 0
        FID = fopen([sourcePath '\' Files(i).name],'rb','ieee-be');
        while ~ feof (FID)% find the image size in PhoenixHeader
            Text = fgetl(FID);
            if ~isempty(strfind(Text,'NumberOfColumns'))
                ImgColumns = str2double(Text(18:end));
                Text = fgetl(FID);
                ImgRows = str2double(Text(15:end));
                break;
            end
        end
        while  ~ feof (FID)% skip PhoenixHeader
            Text = fgetl(FID);
            if ~isempty(strfind(Text,'[EndofPhoenixHeader]'))
                break
            end
        end
        Mag = fread(FID,ImgColumns*ImgRows,'float32','ieee-be');
        Img = reshape(Mag,[ImgColumns ImgRows]);
        imwrite(uint8(imadjust(Img)*255),[targetPath '\' Files(i).name(1:end-3) 'tif']); contrast save%    %i noor removed Adjusted before contrast becuase of generating error. 
        clear ImgColumns ImgRows
        fclose(FID);
    else
        if strcmp(Files(i).name,'.') ~= 1 && strcmp(Files(i).name,'..') ~= 1
            if ~exist([targetPath '\' Files(i).name],'dir')
                mkdir([targetPath '\' Files(i).name]);
            end
            MSTAR2JPG([sourcePath '\' Files(i).name],[targetPath '\' Files(i).name]);
        end
    end
end
end