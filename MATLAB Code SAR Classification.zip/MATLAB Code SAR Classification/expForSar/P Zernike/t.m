clear
rgbTank=imread('tank.jpg');
subplot(3,2,1);imshow(rgbTank);
subplot(3,2,2);imhist(rgbTank);



tankEq=histeq(rgbTank);
subplot(3,2,3);imhist(tankEq);
subplot(3,2,4);imshow(tankEq);


h = fspecial('average',20);
filterTank=imfilter(tankEq,h);
subplot(3,2,5);imshow(filterTank);

bwTank=im2bw(filterTank,0.8);
subplot(3,2,6);imshow(bwTank);

imwrite(bwTank,'bw.png');
