

imgArr={        


};
for i = 1:length(imgArr)
    img=char(imgArr(i));
    I = imread([pwd,'\expForSar\CopyandSave\img\',img]) ;   % REad image 
    %[filepath,name,ext] = fileparts(imgArr(i)) ;
    imwrite(I,img);   % Save image 
end

