% THIS SOFTWARE AND ANY ACCOMPANYING DOCUMENTATION IS RELEASED "AS IS."  THE U.S. GOVERNMENT MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, CONCERNING THIS SOFTWARE AND ANY ACCOMPANYING DOCUMENTATION, INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT WILL THE U.S. GOVERNMENT BE LIABLE FOR ANY DAMAGES, INCLUDING ANY LOST PROFITS, LOST SAVINGS OR OTHER INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE, OR INABILITY TO USE, THIS SOFTWARE OR ANY ACCOMPANYING DOCUMENTATION, EVEN IF INFORMED IN ADVANCE OF THE POSSIBILITY OF SUCH DAMAGES.
%
% filename: show_chip.m
%
% Part of the AdaptSAPS problem set (ref. https://www.mbvlab.wpafb.af.mil/public/sdms/datasets/mstar/overview.htm)
%
% Inputs
%   filename (possibly including directory) for a image chip in MSTAR format
%
% 030701 ljh original

function NR = show_chip(fname)
   %fname = 'HB03333.000'

 figure;
   fid = fopen(fname,'r');
   N=0;
   while(N<3)  % Read the header information for loading the chip
      schar = fgets(fid);
      scharl = length(schar);
      ptb = strfind(schar,'=');
      if(length(strfind(schar,'EndofPhoenixHeader')) > 0)
         N=3;
      elseif(length(ptb) > 0)
         pt=ptb(1);
         if(length(strfind(schar,'PhoenixHeaderLength')) > 0)
             ptbp = schar(pt+1:scharl-1);
             N = N+1;
             PHL = sscanf(ptbp,'%f');
         elseif(length(strfind(schar,'NumberOfColumns')) > 0)
             ptbp = schar(pt+1:scharl-1);
             N = N+1;
             NC = sscanf(ptbp,'%f');
         elseif(length(strfind(schar,'NumberOfRows')) > 0)
             ptbp = schar(pt+1:scharl-1);
             N = N+1;
             NR = sscanf(ptbp,'%f');
         end     
      end
   end
   fclose(fid);

   fid = fopen(fname,'r','ieee-be');  % load the chip to be inserted.
   s1 = fread(fid,PHL,'char');
   %s1 = fread(fid,512,'char');       % chips do not have a native header.
   s1 = fread(fid,NR*NC,'float');     % chips are in float - this reads the magnitude only.
   s1 = s1';
   fclose(fid);
   if length(s1) == 0 error('Failed to read any data.'); end;
   s2 = reshape(s1,NC,NR);
   s1 = abs(s2)';
   s2 = 20*log10(500*s1+3);                   %s2 log TARGET Display
   colormap('gray');
   h = imagesc(s2);
   str = rmv_underscore(sprintf('%s',fname));
   if length(str) > 40
       str = ['... ' str(length(str)-40 : end)];
   end;
   NR=fid;
  
 title(str);

