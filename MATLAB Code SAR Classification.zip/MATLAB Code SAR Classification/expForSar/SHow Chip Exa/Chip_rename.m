% THIS SOFTWARE AND ANY ACCOMPANYING DOCUMENTATION IS RELEASED "AS IS."  THE U.S. GOVERNMENT MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, CONCERNING THIS SOFTWARE AND ANY ACCOMPANYING DOCUMENTATION, INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT WILL THE U.S. GOVERNMENT BE LIABLE FOR ANY DAMAGES, INCLUDING ANY LOST PROFITS, LOST SAVINGS OR OTHER INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE, OR INABILITY TO USE, THIS SOFTWARE OR ANY ACCOMPANYING DOCUMENTATION, EVEN IF INFORMED IN ADVANCE OF THE POSSIBILITY OF SUCH DAMAGES.
%
% filename: Chip_rename.m
%
% Part of the AdaptSAPS problem set (ref. https://www.mbvlab.wpafb.af.mil/public/sdms/datasets/mstar/overview.htm)
%
% This copies a file, dropping any info from the header concerning the Parentsource, Object, and Target.  
% It also renames the Filename in the header. 
% This is used by sarOracle.m to serve test images to the System-Under-Test without providing target truth information.
%
% 030702 ljh original

function Chip_rename(old_name,new_name)
%old_name = 'HB03333.000';
%new_name = sprintf('%s.new',fname);
fid = fopen(old_name,'r');
wfid = fopen(new_name,'w');
schar = '';
%disp('1st Pass:');
while ( length(strfind(schar,'[EndofPhoenixHeader]')) == 0 )
   schar = fgets(fid);
   scharl = length(schar);
   ptb = strfind(schar,'=');
   drop_line = 0;
   if(length(strfind(schar,'EndofPhoenixHeader')) > 0 )
   elseif(length(ptb) > 0)
      pt=ptb(1);
      if(length(strfind(schar,'PhoenixHeaderLength')) > 0)
         ptbp = schar(pt+1:scharl-1);
         PHL = sscanf(ptbp,'%f');
      elseif(length(strfind(schar,'NumberOfColumns')) > 0)
         ptbp = schar(pt+1:scharl-1);
         NC = sscanf(ptbp,'%f');
      elseif(length(strfind(schar,'NumberOfRows')) > 0)
         ptbp = schar(pt+1:scharl-1);
         NR = sscanf(ptbp,'%f');
      elseif(length(strfind(schar,'Filename')) > 0)
         schar = sprintf('Filename= %s\n',new_name);
      elseif(length(strfind(schar,'Object')) > 0 )
%        str = sprintf('Drop (Object): %s',schar);
%         disp(str);
         drop_line = 1;
      elseif(length(strfind(schar,'Target')) > 0 )
%         str = sprintf('Drop (Target): %s',schar);
%         disp(str);
         drop_line = 1;
      elseif(length(strfind(schar,'Parent')) > 0 )
%         str = sprintf('Drop (Parent): %s',schar);
%         disp(str);
         drop_line = 1;
      end
   end
   if(drop_line == 0)
      fprintf(wfid,'%s',schar);
%      disp(schar);
   end
end
fclose(fid);
fclose(wfid);
% Read and wrote header info.

DIR = dir(new_name);
hdr_size = DIR(1).bytes;  % New header size.
DIR = dir(old_name);
sig_size = DIR(1).bytes;  % Old Chip size.
delta = PHL - hdr_size;
sig_size = sig_size - delta;  % adjust for smaller header.
str = sprintf('      Old header length = %d',PHL);
%disp(str);
str = sprintf('      New header length = %d',hdr_size);
%disp(str);
str = sprintf('Change in header length = %d',delta);
%disp(str);
str = sprintf('          New file size = %d', sig_size);
%disp(str);
   
   % Now rewrite the header preserving the current byte count on each line.
   % Correct the PhoenixHeaderLength and PhoenixSigSize entries.

fid = fopen(old_name,'r');
wfid  = fopen(new_name,'w');
schar = '';
%disp('2nd Pass:');
while ( length(strfind(schar,'[EndofPhoenixHeader]')) == 0 )
   schar = fgets(fid);
   scharl = length(schar);
   ptb = strfind(schar,'=');
   drop_line = 0;
   if(length(strfind(schar,'EndofPhoenixHeader')) > 0 )
   elseif(length(ptb) > 0)
      pt=ptb(1);
     %Replace the info with the correct size.
      if(length(strfind(schar,'PhoenixHeaderLength')) > 0)
         schar = sprintf('PhoenixHeaderLength= 0%d\n',hdr_size);
      elseif(length(strfind(schar,'PhoenixSigSize')) > 0)
         if ( sig_size > 99999 )
            schar = sprintf('PhoenixSigSize= 00%d\n',sig_size);
         else
            schar = sprintf('PhoenixSigSize= 000%d\n',sig_size);
         end
      elseif(length(strfind(schar,'Object')) > 0 )
         drop_line = 1;
      elseif(length(strfind(schar,'Target')) > 0 )
         drop_line = 1;
      elseif(length(strfind(schar,'Parent')) > 0 )
         drop_line = 1;
      elseif(length(strfind(schar,'Filename')) > 0)
         schar = sprintf('Filename= %s\n',new_name);
      end
   end
   if(drop_line == 0)
      fprintf(wfid,'%s',schar);
   end
end
fclose(fid);
fclose(wfid);

% Next copy the chip data over to the new file.

%disp('Reading the image:');
fid = fopen(old_name,'r','ieee-be');
mag = fread(fid,PHL,'char');
mag = fread(fid,NR*NC,'float');   % Read the magnitude data.
phase = fread(fid,NR*NC,'float'); % Read the phase data.
fclose(fid);

%disp('Writing the image:');
wfid = fopen(new_name,'a','ieee-be');
fwrite(wfid,mag,'float');          % Write the magnitude data.
fwrite(wfid,phase,'float');        % Write the phase data.
fclose(wfid);  