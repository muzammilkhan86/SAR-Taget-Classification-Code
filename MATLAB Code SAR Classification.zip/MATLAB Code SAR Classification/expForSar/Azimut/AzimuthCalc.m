function AzimuthPoints=AzimuthCalc(lat,long)
tic

clc
close all

AzimuthPoints=zeros(length(lat));

for ii=1:length(lat)
    for jj=ii+1:length(lat)
        AzimuthPoints(ii,jj)=azimuth('rh',lat(ii,1),long(ii,1),lat(jj,1),long(jj,1));
    end
end

toc
end