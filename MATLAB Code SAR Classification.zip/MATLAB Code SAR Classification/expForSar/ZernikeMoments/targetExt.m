function target = targetExt(img)

pic=imread(img); 
pic_bw=im2bw(pic); 

pic_heq=histeq(pic);

h=fspecial('average',9);
pic_filt=imfilter(pic_heq,h);

target=im2bw(pic_filt,0.8);

end

