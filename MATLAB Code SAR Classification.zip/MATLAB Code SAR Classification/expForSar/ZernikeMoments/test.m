

clc; clear all; close all;
n = 4; m = 2;           % Define the order and the repetition of the moment
disp('------------------------------------------------');
disp(['Calculating Zernike moments ..., n = ' num2str(n) ', m = ' num2str(m)]);
%--------------------------------------------------------------------------
% row 1

    %p=imread('C:\Users\NoorRahman\Documents\MATLAB\SAR\Converting2jpg\testT\HB03334.jpg');
    p=targetExt([pwd,'\expForSar\ZernikeMoments\bmp22.png']);
    %p=im2bw(p);     
   %p=p';
   imshow(p);
title('Horizontal oval');
%p = logical(not(p));
tic
[ZZ, AOH, PhiOH] = Zernikmoment(p,n,m);      % Call Zernikemoment fuction
Elapsed_time = toc;
xlabel({['Z = ' num2str(ZZ)];['A = ' num2str(AOH)]; ['\phi = ' num2str(PhiOH)]});