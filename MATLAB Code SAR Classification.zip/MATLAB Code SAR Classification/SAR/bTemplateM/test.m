clear all;
clc;


sourcePath=[pwd,'\SAR\Img\TestSet\SOC\BMP2\'];
Files = dir([sourcePath,'*.tif']);
for i = 1:length(Files)
   if Files(i).isdir == 1       
   else

   img=imread([sourcePath,Files(i).name]);

testImg=bImageTarget(img);
targetAng=tAngle(testImg);


%------------------------- For BMP2 ------------------
bmp2sourcePath=([pwd,'\SAR\Img\TrainSet\SOC\BMP2\']);
 bmp2Img=checkAng(bmp2sourcePath,targetAng);
 bmp2templateImg=imread(bmp2Img);
 bmp2templateImg=bImageTarget(bmp2templateImg);
 bmp2sim=corr2(testImg,bmp2templateImg);

%------------------------- For BTR70 ------------------
btrsourcePath=([pwd,'\SAR\Img\TrainSet\SOC\BTR70\']);
btrImg=checkAng(btrsourcePath,targetAng);
btrtemplateImg=imread(btrImg);
btrtemplateImg=bImageTarget(btrtemplateImg);
btrsim=corr2(testImg,btrtemplateImg);
%------------------------- For T72 ------------------
t72sourcePath=([pwd,'\SAR\Img\TrainSet\SOC\T72\']);
t72Img=checkAng(t72sourcePath,targetAng);
t72templateImg=imread(t72Img);
t72templateImg=bImageTarget(t72templateImg);
t72sim=corr2(testImg,t72templateImg);

if bmp2sim>btrsim && bmp2sim>t72sim
    target='BMP2';
elseif btrsim>bmp2sim && btrsim>t72sim
    target='BTR70';
else
    target='T72';
end

ftarget{i,:}={target};
fname{i,:}={Files(i).name};
   end
   end
%montage({bmp2templateImg,testImg})
