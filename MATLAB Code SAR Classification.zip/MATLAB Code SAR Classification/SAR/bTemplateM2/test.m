clear all;
clc;
class='T72';
sourcePath=[pwd,'\SAR\Img\TestSet\SOC\',class,'\'];
Files = dir([sourcePath,'*.tif']);
for i = 1:length(Files)
   if Files(i).isdir == 1       
   else

   img=imread([sourcePath,Files(i).name]);

testImg=bImageTarget(img);
targetAng=tAngle(testImg);

bmp2sim=bmp2Sim(testImg,targetAng);
btrsim=btrSim(testImg,targetAng);
t72sim=t72Sim(testImg,targetAng);
 


if bmp2sim > btrsim && bmp2sim > t72sim
    target='BMP2';
elseif btrsim>bmp2sim && btrsim>t72sim
    target='BTR70';
else
    target='T72';
end


ftarget{i,:}={target};
fname{i,:}={Files(i).name};
   end
   end
%montage({bmp2templateImg,testImg})
